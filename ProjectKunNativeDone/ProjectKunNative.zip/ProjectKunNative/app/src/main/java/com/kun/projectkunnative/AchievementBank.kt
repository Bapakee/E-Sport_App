package com.kun.projectkunnative

import com.google.gson.annotations.SerializedName

data class AchievementBank(var id:Int,
                           @SerializedName("game_id") var gameId:Int,
                           @SerializedName("achievement")var achievement: String,
                           @SerializedName("tahun")var tahun: Int,
                           @SerializedName("team_id")var teamId:Int
) {
}