package com.kun.projectkunnative

import com.google.gson.annotations.SerializedName

data class MemberBank(var id:Int,
                      @SerializedName("photo")var picture:String,
                      var username:String,
                      var role:String,
                      var password:String,
                      var fname:String,
                      var lname:String

    ) {
}