package com.kun.projectkunnative

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.get
import androidx.fragment.app.Fragment
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.snackbar.Snackbar
import com.kun.projectkunnative.databinding.ActivityMainBinding
import com.kun.projectkunnative.databinding.DrawerLayoutBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding:DrawerLayoutBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DrawerLayoutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sharedPreferences: SharedPreferences =
            getSharedPreferences("SETTING", Context.MODE_PRIVATE)

        setSupportActionBar(binding.include.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(false)
        supportActionBar?.title = "Esport"


        var drawerToggle = ActionBarDrawerToggle(this, binding.drawerLayout,
            binding.include.toolbar, R.string.app_name, R.string.app_name)

        drawerToggle.isDrawerIndicatorEnabled = true
        drawerToggle.syncState()

        binding.navView.setNavigationItemSelectedListener{
            if(it.itemId == R.id.menuSignOut){
                sharedPreferences.edit().putInt("Login",0).apply()
                sharedPreferences.edit().putString("Nama","").apply()
                binding.navView.context.startActivity(Intent(binding.navView.context,SignInPage::class.java))
            }else if (it.itemId == R.id.menuApply){
                binding.navView.context.startActivity(Intent(binding.navView.context,ApplyTeam::class.java))
            }
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            true
        }



        val fragments: ArrayList<Fragment> = ArrayList()

        fragments.add(WhatWePlayFragment())
        fragments.add(WhoWeAreFragment())
        fragments.add(ScheduleFragment())

        val viewpager = binding.include.viewPager
        val bottonNav = binding.include.bottomNav
        viewpager.adapter = MyAdapter(this, fragments)
        viewpager.registerOnPageChangeCallback(object:
            ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    bottonNav.selectedItemId =
                        bottonNav.menu.getItem(position).itemId
                    // Or: binding.bottomNav.selectedItemId =
                    bottonNav.menu[position].itemId
                }
            }
        )

        bottonNav.setOnItemSelectedListener {
            viewpager.currentItem = when(it.itemId) {
                R.id.itemWhatweplay -> 0
                R.id.itemGroup -> 1
                R.id.itemSchedule -> 2
                else -> 0 // default to home
            }
            true
        }
    }
}