package com.kun.projectkunnative

import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.kun.projectkunnative.databinding.ActivityTeamMainPageBinding
import com.kun.projectkunnative.databinding.ActivityTeamsPageBinding
import com.squareup.picasso.Picasso
import org.json.JSONObject

class TeamMainPage : AppCompatActivity() {
    private lateinit var binding: ActivityTeamMainPageBinding

    private lateinit var recyclerView: RecyclerView
    var teamArray:ArrayList<TeamBank> = ArrayList()
    var selectedTeam:ArrayList<TeamBank> = ArrayList()
    private lateinit var adapterr : TeamAdapter
    var index:Int =0
    var foto:String =""
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        binding = ActivityTeamMainPageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        recyclerView = binding.recTeam
        index = intent.getIntExtra(GameAdapter.INDEX,0)
        foto = intent.getStringExtra(GameAdapter.FOTO).toString()

        val builder = Picasso.Builder(binding.imageView2.context)
        builder.listener { picasso, uri, exception ->
            exception.printStackTrace()
        }
        builder.build().load(foto).into(binding.imageView2)

        getArray()
        updateList()


    }
    fun updateList() {
        val lm = LinearLayoutManager(this)
        with(recyclerView) {
            layoutManager = lm
            setHasFixedSize(true)
            for (j in teamArray){
                if(j.game_id==index+1){
                    selectedTeam.add(j)
                }
            }
            Log.d("cekisiarray", index.toString())
            adapterr = TeamAdapter(selectedTeam,foto)
            recyclerView.adapter = adapterr
        }
    }
    fun getArray(){
        val q = Volley.newRequestQueue(this)
        val url = "https://ubaya.xyz/native/160422104/get_team.php"
        var stringRequest = StringRequest(
            Request.Method.POST, url,
            {
                Log.d("apiresult", it)
                val obj = JSONObject(it)
                if(obj.getString("result") == "OK") {
                    val data = obj.getJSONArray("data")
                    val sType = object : TypeToken<List<TeamBank>>() { }.type
                    teamArray = Gson().fromJson(data.toString(), sType) as
                            ArrayList<TeamBank>
                }
                updateList()
                Log.d("cekisiarray", teamArray.toString())
            },
            {
                Log.e("apiresult", it.message.toString())
            }
        )
        q.add(stringRequest)
    }
}