package com.kun.projectkunnative

import com.google.gson.annotations.SerializedName

data class EventTeamBank (var idevent:Int,
                          var idteam:Int
    ){
}