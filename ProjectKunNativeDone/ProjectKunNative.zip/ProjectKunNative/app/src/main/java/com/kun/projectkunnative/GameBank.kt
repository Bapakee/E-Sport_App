package com.kun.projectkunnative

import com.google.gson.annotations.SerializedName

data class GameBank(var id:Int,
                    @SerializedName("nama") var game: String?,
                    @SerializedName("gambar") var picture: String?,
                    @SerializedName("description") var description: String?) {
}