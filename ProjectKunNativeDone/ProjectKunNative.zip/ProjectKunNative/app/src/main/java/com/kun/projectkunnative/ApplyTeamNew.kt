package com.kun.projectkunnative

import android.R
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.kun.projectkunnative.databinding.ActivityApplyTeamNewBinding
import com.kun.projectkunnative.databinding.ActivitySchedulePageBinding
import org.json.JSONObject

class ApplyTeamNew : AppCompatActivity() {
    private lateinit var binding: ActivityApplyTeamNewBinding
    var teamArray:ArrayList<TeamBank> = ArrayList()
    var gameArray:ArrayList<GameBank> = ArrayList()
    var listOfGames :ArrayList<String> =ArrayList()
    var listOfTeam :ArrayList<String> =ArrayList()
    var gameid = 0
    var teamid = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityApplyTeamNewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val q = Volley.newRequestQueue(this)
        val url = "https://ubaya.xyz/native/160422104/get_game.php"
        var stringRequest = StringRequest(
            Request.Method.POST, url,
            {
                Log.d("apiresult", it)
                val obj = JSONObject(it)
                if(obj.getString("result") == "OK") {
                    val data = obj.getJSONArray("data")
                    val sType = object : TypeToken<List<GameBank>>() { }.type
                    gameArray = Gson().fromJson(data.toString(), sType) as
                            ArrayList<GameBank>

                }
                for (game in gameArray){
                    listOfGames.add(game.game.toString())
                }
                val gameAdapter = ArrayAdapter(this, R.layout.simple_spinner_item, listOfGames)
                gameAdapter.setDropDownViewResource(R.layout.simple_spinner_dropdown_item)
                binding.spinnerGame.adapter = gameAdapter

                binding.spinnerGame.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?,
                                                position: Int, id: Long) {

                        val selectedGame = gameArray[position].game.toString()
                        gameid = gameArray[position].id
                        Log.d("spinnerSelection", "Selected game: $gameid")
                        val qs = Volley.newRequestQueue(binding.spinnerGame.context)
                        val urls = "https://ubaya.xyz/native/160422104/get_team_game_activity.php"
                        val stringRequests = object : StringRequest(Request.Method.POST, urls,
                            Response.Listener {
                                Log.d("cekparams", it)
                                fetchTeamsForGame(gameid)
                            },
                            Response.ErrorListener {
                                Log.d("cekparams", it.message.toString())
                            }
                        )
                        {
                            override fun getParams() = hashMapOf(
                                "game" to selectedGame
                            )
                        }
                        qs.add(stringRequests)
                    }

                    override fun onNothingSelected(parent: AdapterView<*>?) {

                    }
                }
                binding.spinnerTeam.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?,
                                                position: Int, id: Long) {
                        val teamName = listOfTeam[position]
                        for(team in teamArray){
                            if(team.nama==teamName){
                                teamid=team.id
                            }
                        }
                        Log.d("CekTeamId",teamid.toString())
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {

                    }
                }
                binding.buttonApply.setOnClickListener(){
                    val qa = Volley.newRequestQueue(binding.buttonApply.context)
                    val urla = "https://ubaya.xyz/native/160422104/applynewteam.php"
                    val stringRequesta = object : StringRequest(Request.Method.POST, urla,
                        Response.Listener {
                            val obj = JSONObject(it)
                            if(obj.getString("result")=="OK"){
                                Toast.makeText(this, "Join Proposal Successfull", Toast.LENGTH_SHORT).show()
                                val intent = Intent(this, ApplyTeam::class.java)
                                startActivity(intent)
                                finish()
                            } else{
                                Toast.makeText(this, "Join Proposal Successfull", Toast.LENGTH_SHORT).show()
                            }
                            Log.d("cekparams", it)
                        },
                        Response.ErrorListener {
                            Log.d("cekparams", it.message.toString())
                        }
                    )
                    {
                        override fun getParams(): MutableMap<String, String> {
                            val params = HashMap<String, String>()
                            val sharedPreferences: SharedPreferences =
                                getSharedPreferences("SETTING", Context.MODE_PRIVATE)
                            var idmember = sharedPreferences.getInt("idmember",
                                0).toString()
                            params["idmember"] = idmember
                            params["idteam"] = teamid.toString()
                            params["description"] = binding.editTextDescription.text.toString()
                            return params
                        }
                    }
                    qa.add(stringRequesta)
                }

                Log.d("cekisiarray", listOfGames.toString())
            },
            {
                Log.e("apiresult", it.message.toString())
            }
        )
        q.add(stringRequest)
    }
    private fun fetchTeamsForGame(gameeeid: Int) {
        val q = Volley.newRequestQueue(this)
        val url = "https://ubaya.xyz/native/160422104/get_team.php"
        var stringRequest = StringRequest(
            Request.Method.POST, url,
            {
                Log.d("apiresult", it)
                val obj = JSONObject(it)
                if(obj.getString("result") == "OK") {
                    val data = obj.getJSONArray("data")
                    val sType = object : TypeToken<List<TeamBank>>() { }.type
                    teamArray = Gson().fromJson(data.toString(), sType) as
                            ArrayList<TeamBank>
                }
                // Update the list of teams
                listOfTeam.clear()
                for (team in teamArray) {
                    if(team.game_id==gameeeid){
                        listOfTeam.add(team.nama.toString())
                    }
                }
                val teamAdapter = ArrayAdapter(this, R.layout.simple_spinner_item, listOfTeam)
                teamAdapter.setDropDownViewResource(R.layout.simple_spinner_dropdown_item)
                // Set this adapter to a different spinner (e.g., `spinnerTeam`)
                binding.spinnerTeam.adapter = teamAdapter
                Log.d("cekisiarray", teamArray.toString())
            },
            {
                Log.e("apiresult", it.message.toString())
            }
        )
        q.add(stringRequest)
    }
}