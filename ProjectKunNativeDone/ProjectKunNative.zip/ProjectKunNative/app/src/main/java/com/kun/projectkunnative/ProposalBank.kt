package com.kun.projectkunnative

import com.google.gson.annotations.SerializedName

class ProposalBank(@SerializedName("idmember") val id:Int?,
                   @SerializedName("nama") val gameName: String?,
                   @SerializedName("status") val status: String?)
