package com.kun.projectkunnative

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.kun.projectkunnative.databinding.TeamCardBinding
import com.kun.projectkunnative.databinding.TeamMemberCardBinding
import com.squareup.picasso.Picasso

class TeamMemberAdapter(var teams: ArrayList<MemberBank>): RecyclerView.Adapter<TeamMemberAdapter.TeamMemberViewHolder>() {
    class TeamMemberViewHolder(val binding:
                         TeamMemberCardBinding
    ): RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TeamMemberViewHolder {
        val binding = TeamMemberCardBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,false)

        return TeamMemberViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return teams.size
    }

    override fun onBindViewHolder(holder: TeamMemberViewHolder, position: Int) {
        Log.d("cekRecView",teams[position].username)
        holder.binding.txtName.text=teams[position].username
        holder.binding.txtTeamRole.text=teams[position].role
        val builder = Picasso.Builder(holder.binding.imgUser.context)
        builder.listener { picasso, uri, exception ->
            exception.printStackTrace()
        }
        builder.build().load(teams[position].picture).into(holder.binding.imgUser)
    }

}