package com.kun.projectkunnative

import android.os.Bundle
import android.util.EventLogTags
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.kun.projectkunnative.databinding.ActivitySchedulePageDetailBinding
import com.squareup.picasso.Picasso
import org.json.JSONObject

class SchedulePageDetail : AppCompatActivity() {
    private lateinit var binding: ActivitySchedulePageDetailBinding
    var index:Int =0
    var scheduleArray:ArrayList<ScheduleBank> = ArrayList()
    var eventTeam:ArrayList<EventTeamBank> = ArrayList()
    var selectedeventTeam:ArrayList<Int> = ArrayList()
    var teamArray:ArrayList<TeamBank> = ArrayList()
    var selectedteamArray:ArrayList<String> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        index =intent.getIntExtra(ScheduleAdapter.INDEX,0)

        getArrayEventTeam()
        getArrayTeam()
        getArray()
        binding = ActivitySchedulePageDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonNotify.setOnClickListener{
            Toast.makeText(this,"Notification Created", Toast.LENGTH_SHORT).show()
        }
    }
    fun getArray(){
        val q = Volley.newRequestQueue(this.baseContext)
        val url = "https://ubaya.xyz/native/160422104/get_event.php"
        var stringRequest = StringRequest(
            Request.Method.POST, url,
            {
                Log.d("apiresult", it)
                val obj = JSONObject(it)
                if(obj.getString("result") == "OK") {
                    val data = obj.getJSONArray("data")
                    val sType = object : TypeToken<List<ScheduleBank>>() { }.type
                    scheduleArray = Gson().fromJson(data.toString(), sType) as
                            ArrayList<ScheduleBank>
                }
                for(event in scheduleArray){
                    if(event.id==index){
                        Log.d("cekindex", index.toString())
                        binding.textViewEventDesc.text=event.description

                        binding.textViewEventDateTime.text= event.location+" (" + event.time + ")"
                        binding.textViewEventHeader.text=event.title
                        var stringTeam = ""
                        for(team in selectedteamArray){
                            stringTeam+=team+"\n"
                        }
                        binding.textViewAffectedTeam.text=stringTeam
                        val builder = Picasso.Builder(binding.imageViewEvent.context)
                        builder.listener { picasso, uri, exception ->
                            exception.printStackTrace()
                        }
                        builder.build().load(event.picture).into(binding.imageViewEvent)
                    }
                }
                Log.d("cekArray", scheduleArray.toString())
                Log.d("cekisiarray", scheduleArray.toString())
            },
            {
                Log.e("apiresult", it.message.toString())
            }
        )
        q.add(stringRequest)
    }
    fun getArrayEventTeam(){
        val q = Volley.newRequestQueue(this.baseContext)
        val url = "https://ubaya.xyz/native/160422104/get_event_team.php"
        var stringRequest = StringRequest(
            Request.Method.POST, url,
            {
                Log.d("apiresult", it)
                val obj = JSONObject(it)
                if(obj.getString("result") == "OK") {
                    val data = obj.getJSONArray("data")
                    val sType = object : TypeToken<List<EventTeamBank>>() { }.type
                    eventTeam = Gson().fromJson(data.toString(), sType) as
                            ArrayList<EventTeamBank>
                }
                for (eventTim in eventTeam){
                    if(eventTim.idevent==index){
                        selectedeventTeam.add(eventTim.idteam)
                    }
                }
                Log.d("cekisiarrayEventTeam", eventTeam.toString())
            },
            {
                Log.e("apiresult", it.message.toString())
            }
        )
        q.add(stringRequest)
    }
    fun getArrayTeam(){
        val q = Volley.newRequestQueue(this)
        val url = "https://ubaya.xyz/native/160422104/get_team.php"
        var stringRequest = StringRequest(
            Request.Method.POST, url,
            {
                Log.d("apiresult", it)
                val obj = JSONObject(it)
                if(obj.getString("result") == "OK") {
                    val data = obj.getJSONArray("data")
                    val sType = object : TypeToken<List<TeamBank>>() { }.type
                    teamArray = Gson().fromJson(data.toString(), sType) as
                            ArrayList<TeamBank>
                }
                for (team in teamArray){
                    if(selectedeventTeam.contains(team.id)){
                        selectedteamArray.add(team.nama.toString())
                    }
                }
                Log.d("cekisiarrayTeam", teamArray.toString())
            },
            {
                Log.e("apiresult", it.message.toString())
            }
        )
        q.add(stringRequest)
    }

}
