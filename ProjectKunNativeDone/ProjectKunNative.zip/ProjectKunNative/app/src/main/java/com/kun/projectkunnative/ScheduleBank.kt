package com.kun.projectkunnative

import com.google.gson.annotations.SerializedName

data class  ScheduleBank (var id:Int,
                          var title: String,
                          @SerializedName("foto")var picture: String,
                          var time: String,
                          var date: Int,
                          var month: String,
                          var location: String,
                          var description: String){
}
