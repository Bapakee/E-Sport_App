package com.kun.projectkunnative

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.kun.projectkunnative.ScheduleAdapter.Companion
import com.kun.projectkunnative.ScheduleAdapter.QuestionViewHolder
import com.kun.projectkunnative.databinding.GameCardBinding
import com.squareup.picasso.Picasso

class GameAdapter(var gameArray:ArrayList<GameBank>): RecyclerView.Adapter<GameAdapter.GameViewHolder>() {
    class GameViewHolder(val binding: GameCardBinding):
        RecyclerView.ViewHolder(binding.root)
    companion object {
        val INDEX = "index"
        val FOTO="foto"
        val NAMA="nama"
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GameViewHolder {
        val binding = GameCardBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,false)

        return GameViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return gameArray.count()
    }

    override fun onBindViewHolder(holder: GameViewHolder, position: Int) {
        Log.d("GameArraySize", "Size: ${gameArray.size}")
        holder.binding.txtEventTitle.text = gameArray[position].game
        holder.binding.txtEventDesc.text = gameArray[position].description
        val builder = Picasso.Builder(holder.binding.cardView.context)
        builder.listener { picasso, uri, exception ->
            exception.printStackTrace()
        }
        builder.build().load(gameArray[position].picture).into(holder.binding.imgEvent)

        //holder.binding.imgEvent.setImageResource(GameData.game[position].picture)

        holder.binding.btnAchievements.setOnClickListener{
            val intent = Intent(holder.binding.cardView.context,AchievementDetail::class.java)
            val index = position
            intent.putExtra(INDEX,index)
            intent.putExtra(NAMA,gameArray[index].game)
            intent.putExtra(FOTO,gameArray[index].picture)
            holder.binding.cardView.context.startActivity(intent)
        }
        holder.binding.btnTeams.setOnClickListener{
            val intent = Intent(holder.binding.cardView.context,TeamMainPage::class.java)
            val index = position
            intent.putExtra(INDEX,index)
            intent.putExtra(FOTO,gameArray[index].picture)
            holder.binding.cardView.context.startActivity(intent)
        }
    }
}