package com.kun.projectkunnative

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.kun.projectkunnative.databinding.ActivityApplyTeamBinding
import com.kun.projectkunnative.databinding.ActivityApplyTeamNewBinding
import org.json.JSONObject

class ApplyTeam : AppCompatActivity() {
    private lateinit var binding: ActivityApplyTeamBinding
    var proposalArray:ArrayList<ProposalBank> = ArrayList()
    var proposals:ArrayList<ProposalBank> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityApplyTeamBinding.inflate(layoutInflater)

        setContentView(binding.root)
        setSupportActionBar(binding.toolbar2)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Esport"



        fun updateList() {
            val lm = LinearLayoutManager(this)
            with(binding.recProposalList) {
                layoutManager = lm
                setHasFixedSize(true)
                binding.recProposalList.adapter = ApplyAdapter(proposalArray)
            }
        }
        val q = Volley.newRequestQueue(this)
        val url = "https://ubaya.xyz/native/160422104/get_proposal_activity.php"
        var stringRequest = StringRequest(
            Request.Method.POST, url,
            {
                Log.d("apiresult", it)
                val obj = JSONObject(it)
                if(obj.getString("result") == "OK") {
                    val data = obj.getJSONArray("data")
                    val sType = object : TypeToken<List<ProposalBank>>() { }.type
                    proposals = Gson().fromJson(data.toString(), sType) as
                            ArrayList<ProposalBank>
                }
                val sharedPreferences: SharedPreferences =
                    getSharedPreferences("SETTING", Context.MODE_PRIVATE)
                var idmember = sharedPreferences.getInt("idmember",
                    0).toString()
                for(proposal in proposals){
                    if(proposal.id.toString() == idmember){
                        proposalArray.add(proposal)
                    }
                }
                updateList()
                Log.d("cekisiarray", proposalArray.toString())
            },
            {
                Log.e("apiresult", it.message.toString())
            }
        )
        q.add(stringRequest)
        binding.floatingActionButton.setOnClickListener(){
            val intent = Intent(this,ApplyTeamNew::class.java)
            this.startActivity(intent)
        }
    }
}