package com.kun.projectkunnative

import android.R
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.kun.projectkunnative.databinding.ActivityAchievementDetailBinding
import com.kun.projectkunnative.databinding.ActivityMainBinding
import com.squareup.picasso.Picasso
import org.json.JSONObject

class AchievementDetail : AppCompatActivity() {
    private lateinit var binding: ActivityAchievementDetailBinding
    var achievementArray:ArrayList<AchievementBank> = ArrayList()
    var selectedArray:ArrayList<AchievementBank> = ArrayList()
    var teamArray:ArrayList<TeamBank> = ArrayList()
    var yearArray:ArrayList<String> = ArrayList()
    var index:Int=0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAchievementDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        yearArray.add("All")
        index = intent.getIntExtra(GameAdapter.INDEX,0)
        val gamePicture = intent.getStringExtra(GameAdapter.FOTO)
        val gameName = intent.getStringExtra(GameAdapter.NAMA)
        Log.d("cekIndex",index.toString())
        getArrayTeam()
        getArrayAchievement()



        val builder = Picasso.Builder(this)
        builder.listener { picasso, uri, exception ->
            exception.printStackTrace()
        }
        builder.build().load(gamePicture).into(binding.imageViewGame)

        binding.textViewGame.text=gameName.toString()

        binding.spinnerYear.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?,
                                        position: Int, id: Long) {
                var tahun = yearArray[position]
                binding.textViewDesc.text=""
                var poin=1
                for (achievement in selectedArray){
                    for (team in teamArray){
                        if(team.id==achievement.teamId){
                            if(tahun=="All"){

                                binding.textViewDesc.append(poin.toString()+". "+achievement.achievement+" ( "+achievement.tahun+" ) - "+team.nama+"\n")
                                poin+=1
                            } else if (tahun==achievement.tahun.toString()) {
                                binding.textViewDesc.append(poin.toString()+". "+achievement.achievement+" ( "+achievement.tahun+" ) - "+team.nama+"\n")
                                poin+=1
                            }
                        }
                    }

                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) { }
        }


    }
    fun getArrayYear(){
        for (achievement in selectedArray){
            if(!(yearArray.contains(achievement.tahun.toString()))){
                yearArray.add(achievement.tahun.toString())
            }
        }
        Log.d("year", yearArray.toString())
    }

    fun getArrayTeam(){
        val q = Volley.newRequestQueue(this)
        val url = "https://ubaya.xyz/native/160422104/get_team.php"
        var stringRequest = StringRequest(
            Request.Method.POST, url,
            {
                Log.d("apiresult", it)
                val obj = JSONObject(it)
                if(obj.getString("result") == "OK") {
                    val data = obj.getJSONArray("data")
                    val sType = object : TypeToken<List<TeamBank>>() { }.type
                    teamArray = Gson().fromJson(data.toString(), sType) as
                            ArrayList<TeamBank>
                }

                Log.d("cekisiarray", teamArray.toString())
            },
            {
                Log.e("apiresult", it.message.toString())
            }
        )
        q.add(stringRequest)
    }
    fun getArrayAchievement(){
        val q = Volley.newRequestQueue(this)
        val url = "https://ubaya.xyz/native/160422104/get_achievement.php"
        var stringRequest = StringRequest(
            Request.Method.POST, url,
            {
                Log.d("apiresult", it)
                val obj = JSONObject(it)
                if(obj.getString("result") == "OK") {
                    val data = obj.getJSONArray("data")
                    val sType = object : TypeToken<List<AchievementBank>>() { }.type
                    achievementArray = Gson().fromJson(data.toString(), sType) as
                            ArrayList<AchievementBank>
                }
                for (achievement in achievementArray){
                    if(achievement.gameId==index+1){
                        selectedArray.add(achievement)
                    }
                }
                getArrayYear()
                val adapter = ArrayAdapter(this, R.layout.simple_spinner_item, yearArray.toArray())
                adapter.setDropDownViewResource(R.layout.simple_spinner_dropdown_item)
                binding.spinnerYear.adapter = adapter
                Log.d("selected", selectedArray.toString())

                Log.d("cekisiarray", selectedArray.toString())
            },
            {
                Log.e("apiresult", it.message.toString())
            }
        )
        q.add(stringRequest)
    }
}


