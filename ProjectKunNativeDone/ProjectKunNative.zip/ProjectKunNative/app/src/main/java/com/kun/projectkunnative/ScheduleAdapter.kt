package com.kun.projectkunnative

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.kun.projectkunnative.databinding.ScheduleCardBinding


class ScheduleAdapter(var arraySchedule:ArrayList<ScheduleBank>) : RecyclerView.Adapter<ScheduleAdapter.QuestionViewHolder>() {
    class QuestionViewHolder(val binding:
                             ScheduleCardBinding
    ): RecyclerView.ViewHolder(binding.root)
    companion object {
        val INDEX = "index"
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QuestionViewHolder {
        val binding = ScheduleCardBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,false)

        return QuestionViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return arraySchedule.count()
    }

    override fun onBindViewHolder(holder: QuestionViewHolder, position: Int) {
        holder.binding.txtDate.text = arraySchedule[position].date.toString()
        holder.binding.txtMonth.text = arraySchedule[position].month.toString()
        holder.binding.txtEventName.text  = arraySchedule[position].title
        holder.binding.txtLocation.text = arraySchedule[position].location
        holder.binding.layout.setOnClickListener{
            val intent = Intent(holder.binding.layout.context,SchedulePageDetail::class.java)
            val index = position
            intent.putExtra(INDEX,arraySchedule[index].id)
            holder.binding.layout.context.startActivity(intent)
        }
    }

}

