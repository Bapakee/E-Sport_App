package com.kun.projectkunnative

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.kun.projectkunnative.GameAdapter.Companion.INDEX
import com.kun.projectkunnative.databinding.ProposalCardBinding

class ApplyAdapter(var teams: ArrayList<ProposalBank>) : RecyclerView.Adapter<ApplyAdapter.ApplyViewHolder>(){
    class ApplyViewHolder(val binding:
                         ProposalCardBinding
    ): RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ApplyViewHolder {
        val binding = ProposalCardBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,false)


        return ApplyViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return teams.size
    }

    override fun onBindViewHolder(holder: ApplyViewHolder, position: Int) {
        Log.d("RecyclerView", "Binding item at position $position: ${teams[position].gameName}")
        holder.binding.txtStatus.text = teams[position].status
        holder.binding.txtProposal.text = teams[position].gameName
    }
}