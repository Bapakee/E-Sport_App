package com.kun.projectkunnative

import com.google.gson.annotations.SerializedName

data class TeamBank(    var id: Int,
                         var nama: String?,
                         var game_id: Int) {
}

