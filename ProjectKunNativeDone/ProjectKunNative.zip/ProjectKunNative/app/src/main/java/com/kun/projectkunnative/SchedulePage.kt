package com.kun.projectkunnative

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.kun.projectkunnative.databinding.ActivitySchedulePageBinding
import org.json.JSONObject

class SchedulePage : AppCompatActivity() {
    private lateinit var binding:ActivitySchedulePageBinding
    var scheduleArray:ArrayList<ScheduleBank> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySchedulePageBinding.inflate(layoutInflater)
        setContentView(binding.root)


        fun updateList() {
            val lm = LinearLayoutManager(this)
            with(binding.recSchedule) {
                layoutManager = lm
                setHasFixedSize(true)
                binding.recSchedule.adapter = ScheduleAdapter(scheduleArray)
            }
        }
        val q = Volley.newRequestQueue(this)
        val url = "https://ubaya.xyz/native/160422104/get_schedule.php"
        var stringRequest = StringRequest(
            Request.Method.POST, url,
            {
                Log.d("apiresult", it)
                val obj = JSONObject(it)
                if(obj.getString("result") == "OK") {
                    val data = obj.getJSONArray("data")
                    val sType = object : TypeToken<List<ScheduleBank>>() { }.type
                    scheduleArray = Gson().fromJson(data.toString(), sType) as
                            ArrayList<ScheduleBank>
                }
                updateList()
                Log.d("cekisiarray", scheduleArray.toString())
            },
            {
                Log.e("apiresult", it.message.toString())
            }
        )
        q.add(stringRequest)


    }
}

