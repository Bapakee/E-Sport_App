package com.kun.projectkunnative

import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.kun.projectkunnative.databinding.ActivityTeamsPageBinding
import com.kun.projectkunnative.databinding.ActivityTeamsPageDetailBinding
import com.squareup.picasso.Picasso
import org.json.JSONObject
import java.lang.reflect.Member

class TeamsPageDetail : AppCompatActivity() {
    private lateinit var binding: ActivityTeamsPageDetailBinding

    private lateinit var adapterr : TeamMemberAdapter
    private lateinit var recyclerView: RecyclerView
    var memberArray:ArrayList<MemberBank> = ArrayList()
    var selectedTeam:ArrayList<MemberBank> = ArrayList()
    var teamMemberList:ArrayList<String> = ArrayList()
    var selectedteamMemberList:ArrayList<String> = ArrayList()
    var teamID:Int = 0
    var teamName:String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTeamsPageDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        recyclerView = binding.recMember

        var foto = intent.getStringExtra(TeamAdapter.Foto)
        val builder = Picasso.Builder(binding.imageView3.context)
        builder.listener { picasso, uri, exception ->
            exception.printStackTrace()
        }
        builder.build().load(foto).into(binding.imageView3)

        teamID = intent.getIntExtra(TeamAdapter.TeamID,0)
        teamName = intent.getStringExtra(TeamAdapter.TeamName).toString()
        binding.textViewTeam.text = teamName

        getArray()
        updateList()
    }
    fun updateList() {
        val lm = LinearLayoutManager(this)
        with(recyclerView) {
            layoutManager = lm
            setHasFixedSize(true)
            for (j in memberArray){
                if(selectedteamMemberList.contains(j.id.toString())){
                    selectedTeam.add(j)
                }
            }
            Log.d("cekisiarray", teamID.toString())
            adapterr = TeamMemberAdapter(selectedTeam)
            recyclerView.adapter = adapterr
        }
    }
    fun getArray(){
        val q = Volley.newRequestQueue(this)
        val url = "https://ubaya.xyz/native/160422104/get_member.php"
        var stringRequest = StringRequest(
            Request.Method.POST, url,
            {
                Log.d("apiresult", it)
                val obj = JSONObject(it)
                if(obj.getString("result") == "OK") {
                    val data = obj.getJSONArray("data")
                    val sType = object : TypeToken<List<MemberBank>>() { }.type
                    memberArray = Gson().fromJson(data.toString(), sType) as
                            ArrayList<MemberBank>
                }
                getTeamMember()

                updateList()
                Log.d("cekisiarray", memberArray.toString())
            },
            {
                Log.e("apiresult", it.message.toString())
            }
        )
        q.add(stringRequest)
    }
    fun getTeamMember(){
        val q = Volley.newRequestQueue(this)
        val url = "https://ubaya.xyz/native/160422104/get_team_member.php"
        var stringRequest = StringRequest(
            Request.Method.POST, url,
            {
                Log.d("apiresult", it)
                val obj = JSONObject(it)
                if(obj.getString("result") == "OK") {
                    val data = obj.getJSONArray("data")
                    for(i in 0 until data.length()) {
                        val playObj = data.getJSONObject(i)
                        val string = playObj.getInt("idteam").toString()+","+playObj.getInt("idmember").toString()
                        teamMemberList.add(string)
                    }

                }
                for (i in teamMemberList){
                    if(teamID.toString()==i.split(",")[0]){
                        var idmember = i.split(",")[1]
                        selectedteamMemberList.add(idmember)
                    }
                }
                updateList()
                Log.d("cekisiarray", memberArray.toString())
            },
            {
                Log.e("apiresult", it.message.toString())
            }
        )
        q.add(stringRequest)
    }
}
