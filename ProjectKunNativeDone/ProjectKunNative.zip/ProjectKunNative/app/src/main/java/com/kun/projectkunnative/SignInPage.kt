package com.kun.projectkunnative

import  android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.kun.projectkunnative.databinding.ActivitySignInPageBinding
import com.squareup.picasso.Picasso
import org.json.JSONObject

class SignInPage : AppCompatActivity() {
    private lateinit var binding:ActivitySignInPageBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignInPageBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val sharedPreferences: SharedPreferences =
            getSharedPreferences("SETTING", Context.MODE_PRIVATE)
        var login = sharedPreferences.getInt("Login",
            0).toString().toInt()

        if(login == 1){
            val intent = Intent(this,MainActivity::class.java)
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            this.startActivity(intent)
            finish()
        }

        binding.signUpButton.setOnClickListener {
            val intent = Intent(this,SignUpPage::class.java)
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            this.startActivity(intent)
            finish()
        }

        var foto = "https://i.pinimg.com/736x/f1/15/53/f11553deb9c99c9b7fc39a4aea032ff3.jpg"
        val builder = Picasso.Builder(binding.logoImageView.context)
        builder.listener { picasso, uri, exception ->
            exception.printStackTrace()
        }
        builder.build().load(foto).into(binding.logoImageView)
        with(binding) {
            submitButton.setOnClickListener {
                val q = Volley.newRequestQueue(binding.submitButton.context)
                val url = "https://ubaya.xyz/native/160422104/login.php"
                val stringRequest = object : StringRequest(Request.Method.POST, url,
                    Response.Listener {
                        Log.d("cekparams", it)
                        val obj = JSONObject(it)

                        if(obj.getString("result") == "OK") {
                            val data = obj.getJSONArray("data")
                            val playObj = data.getJSONObject(0)

                            if (data.length()==1){
                                val editor = sharedPreferences.edit()
                                editor.putInt("Login", 1)
                                editor.putString("Nama",playObj.getString("username").toString())
                                editor.putInt("idmember",playObj.getInt("id"))
                                editor.apply()
                                val intent = Intent(binding.submitButton.context,MainActivity::class.java)
                                binding.submitButton.context.startActivity(intent)
                                finish()
                            }else{
                                val editor = sharedPreferences.edit()
                                editor.putInt("Login", 0)
                                editor.apply()
                                Toast.makeText(binding.submitButton.context, "Login failed please try again", Toast.LENGTH_SHORT).show()
                            }
                            Log.d("cekLength",data.length().toString())
                        }
                    },
                    Response.ErrorListener {
                        Log.d("cekparams", it.message.toString())
                    })
                {
                    override fun getParams(): MutableMap<String, String>     {
                        val params = HashMap<String, String>()
                        params["user"] = binding.editTextUsername.text.toString()
                        Log.d("cekpass", binding.editTextPassword.text.toString())
                        params["pass"] = binding.editTextPassword.text.toString()
                        return params
                    }
                }
                q.add(stringRequest)
            }
        }
    }
}