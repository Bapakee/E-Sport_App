package com.kun.projectkunnative

import android.R
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.kun.projectkunnative.databinding.ActivitySignInPageBinding
import com.kun.projectkunnative.databinding.ActivitySignUpPageBinding
import org.json.JSONObject

class SignUpPage : AppCompatActivity() {
    private lateinit var binding: ActivitySignUpPageBinding
    var teams:ArrayList<String> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignUpPageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        binding.submitButton.setOnClickListener {
            if(binding.repeatPasswordEditText.text.toString()!=binding.passwordEditText.text.toString()){
                Toast.makeText(this, "Password needs to be the same", Toast.LENGTH_SHORT).show()
            }else if (!binding.termsCheckBox.isChecked){
                Toast.makeText(this, "You must agree to our TnC to register", Toast.LENGTH_SHORT).show()
            }
            else {
                val qa = Volley.newRequestQueue(binding.submitButton.context)
                val urla = "https://ubaya.xyz/native/160422104/register.php"
                val stringRequesta = object : StringRequest(
                    Request.Method.POST, urla,
                    Response.Listener {
                        val obj = JSONObject(it)
                        if(obj.getString("result")=="OK"){
                            Toast.makeText(this, "Register Successfull", Toast.LENGTH_SHORT).show()
                            val intent = Intent(this, SignInPage::class.java)
                            startActivity(intent)
                            finish()
                        } else{
                            Toast.makeText(this, "Register Fail", Toast.LENGTH_SHORT).show()
                        }
                        Log.d("cekparams", it)
                    },
                    Response.ErrorListener {
                        Log.d("cekparams", it.message.toString())
                    }
                )
                {
                    override fun getParams(): MutableMap<String, String> {
                        val params = HashMap<String, String>()

                        params["photo"] = binding.photoEditText.text.toString()
                        params["username"] = binding.usernameEditText.text.toString()
                        params["role"] = binding.roleEditText.text.toString()
                        params["password"] = binding.passwordEditText.text.toString()
                        params["fname"] = binding.firstNameEditText.text.toString()
                        params["lname"] = binding.lastNameEditText.text.toString()
                        return params
                    }
                }
                qa.add(stringRequesta)
            }
        }
    }
}
