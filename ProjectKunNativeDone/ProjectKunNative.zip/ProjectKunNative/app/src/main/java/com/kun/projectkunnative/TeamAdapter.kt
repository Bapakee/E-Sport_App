package com.kun.projectkunnative

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.kun.projectkunnative.databinding.TeamCardBinding
import com.squareup.picasso.Picasso

class TeamAdapter(var teams: ArrayList<TeamBank>,var foto:String) : RecyclerView.Adapter<TeamAdapter.TeamViewHolder>() {
    class TeamViewHolder(val binding:
                             TeamCardBinding
    ): RecyclerView.ViewHolder(binding.root)
    companion object {
        val TeamName = "TeamName"
        val TeamID = "teamID"
        val Foto = "foto"
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TeamViewHolder {
        val binding = TeamCardBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,false)

        return TeamViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return teams.size
    }

    override fun onBindViewHolder(holder: TeamViewHolder, position: Int) {
        holder.binding.txtName.text=teams[position].nama
        val teamName= teams[position].nama
        holder.binding.cardView.setOnClickListener{
            val intent = Intent(holder.binding.txtName.context,TeamsPageDetail::class.java)

            intent.putExtra(TeamName,teamName)
            intent.putExtra(Foto,foto)
            intent.putExtra(TeamID,teams[position].id)
            holder.binding.cardView.context.startActivity(intent)
        }
    }
}